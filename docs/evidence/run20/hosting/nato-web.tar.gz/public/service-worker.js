/* Generated manifest values bind this worker to one complete production build. */
const CACHE_NAME = 'nato-shell-v1-d3f42bcf4f3c32153c47729208611163b77789f8c2f11358e0b55b7fb5ace48e';
const RESOURCES = [{"url":"/+not-found.html","sha256":"c84bc43364009ed8be79b3f4e04299670bdf2ec241446974a469f671e30c01d9"},{"url":"/NatoTile-ExtraBold-P5QNDEHJ.ttf","sha256":"b0150a84d5e000fcd276cf13e1863ca8bbaab0ff2a0dfdcfa958a48781dd7aa6"},{"url":"/NatoTile-Italic-AWOPV6AY.ttf","sha256":"50f16c8bec3ed31190d37403b6e15d200274e7a5e43f1a698a86eef7079d862b"},{"url":"/NatoTile-SemiBold-REJGIRDE.ttf","sha256":"2d523d4db59330cd9355818d53b9ea01b09f868e26b72dbe76b33a4e7543177f"},{"url":"/_sitemap.html","sha256":"2ca419e177082fa7a6885a88e68bc3cba40a3b5e57cf376f6428d0d86c33b475"},{"url":"/about.html","sha256":"55e02bcbe21bfc7566f3b10182cf943b5655d79e2d12b536dc864fe256c69fcd"},{"url":"/alphabet.html","sha256":"c86311d5e5b5d800660685d27ae229f00f8b775f46df7ebef2893239847df9cf"},{"url":"/assets/app-W3AARF6X.js","sha256":"5a8083a98106d5d1d27414baff9e4cb40ce4409b5757f156d6850ca33295881e"},{"url":"/audio-help.html","sha256":"41d7852b615690673d13e3621a32ff226f579376df51615fe0635aff0d9db184"},{"url":"/converter.html","sha256":"bc1f8dce545a1734b2f0d2ad3f1ca9b2d46fe33b270429489de9a601b231bf53"},{"url":"/favicon.png","sha256":"df8f62668e8fe86ec2495876136d75bf358df780d67fad67e97b2712bfa38a2f"},{"url":"/index.html","sha256":"15571e2af2ff2ed485a1e9a55017cac4e35cc3f38b3e4de64c48bf6c3b848e4b"},{"url":"/letter-quiz.html","sha256":"f6877d503cf227da9c9c50bed7cd040286e175f92018c32746dbce258e69f859"},{"url":"/menu.html","sha256":"949d99f487434efedbf47ad20656ec3ff948c785516a0542649d6f39c316f393"},{"url":"/privacy.html","sha256":"bdbdbcbef7196d5f5ff9c48370033fd6ded41d80349c58da8e365e40140ba3a9"},{"url":"/progress.html","sha256":"415248073f3974a58d64900b7fecac61ec29beb9ca60f6537b5fc84e31d2264a"},{"url":"/settings.html","sha256":"fe70da57501cea2bc9f8962d581f8fb6e68c28e3edd73de15def003e2490087f"},{"url":"/voice-select.html","sha256":"30ca7117b026c01d85448f43bf2fb1b298020f6fd8aab6d2208fdf774e652c2f"}];
const ROUTES = {"/":"/index.html","/alphabet":"/alphabet.html","/converter":"/converter.html","/letter-quiz":"/letter-quiz.html","/progress":"/progress.html","/menu":"/menu.html","/settings":"/settings.html","/about":"/about.html","/voice-select":"/voice-select.html","/privacy":"/privacy.html","/audio-help":"/audio-help.html","/_sitemap":"/_sitemap.html","/+not-found":"/+not-found.html"};
const paths = new Set(RESOURCES.map(resource => resource.url));

async function prepareShell() {
      // Verify every response before publishing this cache. A partial upload or
      // interrupted installation must never replace a working offline shell.
      const responses = await Promise.all(RESOURCES.map(async resource => {
        const response = await fetch(resource.url, { cache: 'no-store', redirect: 'error' });
        if (!response.ok) throw new Error('Offline resource unavailable');
        const bytes = await response.clone().arrayBuffer();
        const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
          .map(byte => byte.toString(16).padStart(2, '0')).join('');
        if (hash !== resource.sha256) throw new Error('Offline resource version mismatch');
        return [resource.url, response];
      }));
      const cache = await caches.open(CACHE_NAME);
      await Promise.all(responses.map(([url, response]) => cache.put(url, response)));
}
async function shellComplete() {
  const cache = await caches.open(CACHE_NAME);
  return (await Promise.all(RESOURCES.map(resource => cache.match(resource.url)))).every(Boolean);
}
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    try {
      await prepareShell();
    } catch (error) {
      await caches.delete(CACHE_NAME);
      throw error;
    }
  })());
  // Never skipWaiting: all existing app windows must finish before activation.
});

self.addEventListener('message', event => {
  if (event.data?.type !== 'SHELL_STATUS' || !event.ports[0]) return;
  event.waitUntil((async () => {
    try {
      if (!(await shellComplete()) && event.data.repair) await prepareShell();
      event.ports[0].postMessage({ ready: await shellComplete() });
    } catch { event.ports[0].postMessage({ ready: false }); }
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('nato-shell-v1-') && name !== CACHE_NAME)
      .map(name => caches.delete(name)));
  })());
  // Never claim existing pages or force a reload that could lose a draft.
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  let key = url.pathname;
  if (request.mode === 'navigate') {
    // Keep missing assets as 404 rather than serving HTML as JavaScript/fonts.
    if (/\.[^/]+$/.test(key) && !key.endsWith('.html')) return;
    const route = key.replace(/\.html$/, '').replace(/\/+$/, '') || '/';
    key = ROUTES[route === '/index' ? '/' : route] || '/index.html';
  } else if (url.search || !paths.has(key)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(key);
    // Do not mix a missing piece of a pinned build with the latest server build.
    return cached || new Response('Offline copy unavailable. Reconnect and use Menu to retry offline setup.', {
      status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  })());
});
